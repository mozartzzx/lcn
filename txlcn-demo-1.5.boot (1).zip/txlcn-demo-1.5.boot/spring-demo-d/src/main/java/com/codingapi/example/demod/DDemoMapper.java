package com.codingapi.example.demod;

import com.codingapi.example.common.db.mapper.DemoMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * Description:
 * Date: 2018/12/25
 *
 * @author ujued
 */
@Mapper
public interface DDemoMapper extends DemoMapper {
}
