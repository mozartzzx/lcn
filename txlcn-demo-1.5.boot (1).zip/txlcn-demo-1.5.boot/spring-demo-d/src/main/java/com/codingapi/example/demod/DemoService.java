package com.codingapi.example.demod;

/**
 * Description:
 * Date: 2018/12/25
 *
 * @author ujued
 */
public interface DemoService {
    
    String rpc(String value);
}
