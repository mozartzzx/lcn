package com.codingapi.example.common.dubbo;


/**
 * Description:
 * Date: 19-1-29 下午5:30
 *
 * @author ujued
 */
public interface Service4DemoService {

    String transactionC(String value);
}
