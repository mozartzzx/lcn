package com.codingapi.example.common.dubbo;

/**
 * Description:
 * Date: 2018/12/25
 *
 * @author ujued
 */
public interface DDemoService {
    String rpc(String value);
}
