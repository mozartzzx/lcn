txlcn 5.0 demo


使用说明:

1. 本Demo基于5.0.1.RELEASE版本
2. 启动Demo前需先启动事务管理器TM。
3. 更多信息见官网 [http://www.txlcn.org](http://www.txlcn.org)   

