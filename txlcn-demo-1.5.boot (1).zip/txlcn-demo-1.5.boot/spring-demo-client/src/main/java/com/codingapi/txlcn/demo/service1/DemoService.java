package com.codingapi.txlcn.demo.service1;

/**
 * Description:
 * Date: 2018/12/25
 *
 * @author ujued
 */
public interface DemoService {


    String execute(String value);
}
